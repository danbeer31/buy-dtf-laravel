-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: buydtf_fuel_stage
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.22.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2026_01_16_023755_increase_dropbox_token_length',1),(2,'2026_01_16_225545_add_shippo_fields_to_dtforders',2),(3,'2026_01_16_231824_add_shipping_method_to_dtforders',3),(4,'2026_01_17_005600_sync_remote_db_shipping_changes',4),(5,'2026_01_17_020821_add_stripe_fee_to_paymentinfos',5),(6,'2026_01_17_025529_create_stripe_payouts_tables',6),(7,'2026_01_22_232856_add_qbo_and_stripe_ids_to_paymentinfos',7),(8,'2026_01_29_012144_add_qbo_ids_to_stripe_payout_tables',8),(9,'2026_01_29_021640_add_qbo_fee_expense_id_to_paymentinfos_table',9),(10,'2026_01_31_013614_create_stripe_webhook_events_table',10),(11,'2026_01_31_045531_add_thumbnail_to_dtfimages_table',11),(12,'2026_01_31_155550_add_business_id_to_paymentinfos',12),(13,'2026_01_31_181635_add_qbo_invoice_number_to_dtforders_table',13),(14,'2026_01_31_181731_create_stripe_sync_logs_table',14),(15,'2026_01_31_181807_add_qbo_invoice_numbers_to_paymentinfos_table',15),(16,'2026_03_10_120000_create_accounting_reconciliation_checks_table',16),(17,'2026_03_23_110000_add_gang_sheet_fields_to_dtfimages_table',17),(18,'2026_03_28_210000_add_admin_price_overrides_to_orders_and_images',18),(19,'2026_09_18_120000_add_notes_to_stripe_payout_entries_table',19);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-01  2:04:07
